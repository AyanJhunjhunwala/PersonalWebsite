from random import randint
from BoardClasses import Move
from BoardClasses import Board
#The following part should be completed by students.
#Students can modify anything except the class name and exisiting functions and varibles.
class StudentAI():

    def __init__(self,col,row,p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col,row,p)
        self.board.initialize_game()
        self.color = ''
        self.opponent = {1:2,2:1}
        self.color = 2

    def get_move(self, move):
        # Main function: get_move
        import math, random, copy

        if move and len(move) != 0:
            self.board.make_move(move, self.opponent[self.color])
        else:
            self.color = 1

        root_state = copy.deepcopy(self.board)
        moves = root_state.get_all_possible_moves(self.color)
        all_moves = [m for group in moves for m in group] if moves else []

        root = {
            'state': root_state,
            'move': None,
            'parent': None,
            'children': [],
            'wins': 0,
            'visits': 0,
            'untried_moves': all_moves,
            'player': self.color
        }

        iterations = 10000
        exploration = math.sqrt(2)

        # Helper function: uct_select_child
        def uct_select_child(node):
            best_child = None
            best_value = -float('inf')
            for child in node['children']:
                uct_value = (child['wins'] / child['visits'] +
                             exploration * math.sqrt(math.log(node['visits']) / child['visits']))
                if uct_value > best_value:
                    best_value = uct_value
                    best_child = child
            return best_child

        # Helper function: rollout
        def rollout(state, player):
            state_sim = copy.deepcopy(state)
            current_player = player
            while True:
                moves_sim = state_sim.get_all_possible_moves(current_player)
                flat_moves = [m for group in moves_sim for m in group] if moves_sim else []
                if not flat_moves:
                    return self.opponent[current_player]
                move_sim = random.choice(flat_moves)
                state_sim.make_move(move_sim, current_player)
                current_player = self.opponent[current_player]

        for _ in range(iterations):
            node = root
            while node['untried_moves'] == [] and node['children']:
                node = uct_select_child(node)
            if node['untried_moves']:
                move_exp = random.choice(node['untried_moves'])
                node['untried_moves'].remove(move_exp)
                new_state = copy.deepcopy(node['state'])
                new_state.make_move(move_exp, node['player'])
                opp_moves = new_state.get_all_possible_moves(self.opponent[node['player']])
                flat_opp_moves = [m for group in opp_moves for m in group] if opp_moves else []
                child_node = {
                    'state': new_state,
                    'move': move_exp,
                    'parent': node,
                    'children': [],
                    'wins': 0,
                    'visits': 0,
                    'untried_moves': flat_opp_moves,
                    'player': self.opponent[node['player']]
                }
                node['children'].append(child_node)
                node = child_node
            result = rollout(node['state'], node['player'])
            while node is not None:
                node['visits'] += 1
                if result == self.color:
                    node['wins'] += 1
                node = node['parent']

        best_move = None
        best_visits = -1
        for child in root['children']:
            if child['visits'] > best_visits:
                best_visits = child['visits']
                best_move = child['move']

        self.board.make_move(best_move, self.color)
        return best_move
